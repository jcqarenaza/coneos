'use client'

import { useEffect, useState, useRef } from 'react'
import { createClient } from '@/lib/supabase/client'
import { useEmpresa } from '@/lib/useEmpresa'
import { ConePageHeader, ConeButton, ConeCard } from '@/components/admin/ConeComponents'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Loader2, Check, Upload, X } from 'lucide-react'
import Image from 'next/image'

interface Config {
  primary_color: string; secondary_color: string; logo_url: string | null
  texto_bienvenida: string; moneda: string
  cuit: string | null; razon_social: string | null; condicion_iva: string | null; punto_venta: number | null
  pwa_nombre: string | null; pwa_icono_url: string | null
  mostrar_agotados: boolean
  entrada_unificada: boolean
}
interface Empresa { nombre: string; slug: string; plan: string }

export default function ConfigPage() {
  const { ctx, loading: ctxLoading } = useEmpresa()
  const [empresa, setEmpresa] = useState<Empresa | null>(null)
  const [config, setConfig] = useState<Config | null>(null)
  const [saving, setSaving] = useState(false)
  const [saved, setSaved] = useState(false)
  const [sucio, setSucio] = useState(false)
  const tocar = (parcial: Partial<typeof config> & object) => { setSucio(true); setConfig(c => c ? ({ ...c, ...parcial } as typeof c) : c) }
  const [uploadingLogo, setUploadingLogo] = useState(false)
  const logoRef = useRef<HTMLInputElement>(null)

  useEffect(() => {
    if (!ctx) return
    const supabase = createClient()
    Promise.all([
      supabase.from('empresas').select('nombre, slug, plan').eq('id', ctx.empresaId).single(),
      supabase.from('empresa_config').select('primary_color, secondary_color, logo_url, texto_bienvenida, moneda, cuit, razon_social, condicion_iva, punto_venta, pwa_nombre, pwa_icono_url, mostrar_agotados, entrada_unificada').eq('empresa_id', ctx.empresaId).single(),
    ]).then(([{ data: emp }, { data: cfg }]) => {
      if (emp) setEmpresa(emp)
      if (cfg) setConfig({
        ...cfg,
        cuit: cfg.cuit ?? '',
        razon_social: cfg.razon_social ?? '',
        condicion_iva: cfg.condicion_iva ?? 'RI',
        punto_venta: cfg.punto_venta ?? 1,
        mostrar_agotados: cfg.mostrar_agotados ?? false,
        entrada_unificada: cfg.entrada_unificada ?? false,
      })
    })
  }, [ctx])

  async function handleLogoUpload(file: File) {
    if (!ctx) return
    setUploadingLogo(true)
    const supabase = createClient()
    const ext = file.name.split('.').pop()
    // Ciclo 1 (decisión CTO): URL INMUTABLE por subida — cada logo nuevo es un
    // archivo nuevo, y CDN/optimizador de Next/browser/canvas se refrescan por
    // construcción. Nada de ?v=: cache invalidation por diseño, no por parche.
    const path = `logos/${ctx.empresaSlug}-${Date.now()}.${ext}`
    const { error } = await supabase.storage.from('productos').upload(path, file, { upsert: true })
    if (!error) {
      const { data } = supabase.storage.from('productos').getPublicUrl(path)
      setConfig(prev => prev ? { ...prev, logo_url: data.publicUrl } : prev)
    }
    setUploadingLogo(false)
  }

  async function handleSave() {
    if (!ctx || !config) return
    setSaving(true)
    const supabase = createClient()
    const upd = await supabase.from('empresa_config').update({
      primary_color: config.primary_color,
      secondary_color: config.secondary_color,
      logo_url: config.logo_url,
      texto_bienvenida: config.texto_bienvenida,
      moneda: config.moneda,
      cuit: config.cuit || null,
      razon_social: config.razon_social || null,
      condicion_iva: config.condicion_iva || 'RI',
      punto_venta: config.punto_venta || 1,
      pwa_nombre: config.pwa_nombre || null,
      pwa_icono_url: config.pwa_icono_url || null,
      mostrar_agotados: config.mostrar_agotados === true,
      entrada_unificada: config.entrada_unificada === true,
    }).eq('empresa_id', ctx.empresaId)
    setSaving(false)
    if (upd.error) { alert(`No se pudo guardar: ${upd.error.message}`); return }
    setSucio(false)
    setSaved(true); setTimeout(() => setSaved(false), 2500)
  }

  if (ctxLoading || !config || !empresa) return (
    <div className="flex items-center justify-center h-64"><Loader2 className="h-6 w-6 animate-spin text-neutral-300" /></div>
  )

  return (
    <div>
      <ConePageHeader title="Configuración" description="Datos de empresa y preferencias del sistema" />
      {/* Datos de la empresa: solo lectura — banner (para cambios: soporte) */}
      <div className="mb-4 bg-neutral-50 border border-neutral-100 rounded-xl px-4 py-2.5 flex flex-wrap items-center gap-x-6 gap-y-1 text-sm">
        <span className="font-bold text-neutral-700">{empresa.nombre}</span>
        <span className="font-mono text-xs text-neutral-400">/{empresa.slug}</span>
        <span className="text-xs text-neutral-300 ml-auto">Para cambiar estos datos contactá a soporte</span>
      </div>
      <div className="mb-4 flex justify-end items-center">
        <span className={`text-xs font-bold text-amber-600 mr-3 transition-opacity ${sucio && !saving ? 'opacity-100' : 'opacity-0'}`}>● Hay cambios sin guardar</span>
        <ConeButton onClick={handleSave} loading={saving}>
          {saved ? <span className="flex items-center gap-1"><Check className="h-4 w-4" /> ¡Guardado!</span> : 'Guardar cambios'}
        </ConeButton>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">

        <ConeCard title="Datos fiscales">
          <div className="space-y-2.5">
            <div className="p-3 bg-blue-50 border border-blue-100 rounded-xl">
              <p className="text-xs text-blue-700 font-medium">Estos datos se usan para los tickets de caja. La integración con ARCA para facturación electrónica estará disponible próximamente.</p>
            </div>
            <div className="space-y-1">
              <Label>Razón social</Label>
              <Input value={config.razon_social ?? ''} onChange={e => tocar({ razon_social: e.target.value })} placeholder="Cecchetto S.R.L." />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-1">
                <Label>CUIT</Label>
                <Input value={config.cuit ?? ''} onChange={e => tocar({ cuit: e.target.value })} placeholder="30-12345678-9" className="font-mono" />
              </div>
              <div className="space-y-1">
                <Label>Condición IVA</Label>
                <select value={config.condicion_iva ?? 'RI'} onChange={e => tocar({ condicion_iva: e.target.value })}
                  className="w-full px-3 py-2 rounded-xl border border-neutral-200 text-sm focus:outline-none focus:border-neutral-400 bg-white">
                  <option value="RI">Responsable Inscripto</option>
                  <option value="MT">Monotributista</option>
                  <option value="EX">Exento</option>
                  <option value="CF">Consumidor Final</option>
                </select>
              </div>
            </div>
            <div className="space-y-1">
              <Label>Punto de venta</Label>
              <Input type="number" value={config.punto_venta ?? 1} onChange={e => tocar({ punto_venta: Number(e.target.value) })} className="w-24 font-mono" />
              <p className="text-xs text-neutral-400">Número de punto de venta habilitado en AFIP</p>
            </div>
          </div>
        </ConeCard>

        <ConeCard title="Configuración de pedidos">
          <div className="space-y-2.5">
            <div className="space-y-1">
              <Label>Moneda</Label>
              <Input value={config.moneda} onChange={e => tocar({ moneda: e.target.value })} placeholder="ARS" className="w-32" />
            </div>
            {/* Toggle agotados (default OFF = ocultar, comportamiento histórico) */}
            <button type="button" onClick={() => tocar({ mostrar_agotados: !config.mostrar_agotados })}
              className="w-full flex items-center justify-between gap-3 p-3 bg-neutral-50 rounded-xl border border-neutral-100 hover:bg-neutral-100 transition-colors text-left">
              <div>
                <p className="text-sm font-semibold text-neutral-700">Mostrar productos agotados en el catálogo</p>
                <p className="text-xs text-neutral-400 mt-1">Encendido: el producto sin stock se ve griseado como &quot;Agotado&quot; (no se puede comprar). Apagado: desaparece del catálogo hasta que vuelva el stock.</p>
              </div>
              <span className={`flex-shrink-0 w-11 h-6 rounded-full transition-colors relative ${config.mostrar_agotados ? 'bg-neutral-800' : 'bg-neutral-200'}`}>
                <span className={`absolute top-0.5 w-5 h-5 bg-white rounded-full shadow transition-all ${config.mostrar_agotados ? 'left-[22px]' : 'left-0.5'}`} />
              </span>
            </button>
            {/* Ciclo 2 — Entrada unificada de pedidos (default OFF: la ruta
                /pedidos/ es inalcanzable hasta encender esto; las URLs y QR
                actuales de delivery/TA funcionan SIEMPRE, con esto ON u OFF) */}
            <button type="button" onClick={() => tocar({ entrada_unificada: !config.entrada_unificada })}
              className="w-full flex items-center justify-between gap-3 p-3 bg-neutral-50 rounded-xl border border-neutral-100 hover:bg-neutral-100 transition-colors text-left">
              <div>
                <p className="text-sm font-semibold text-neutral-700">App de pedidos de la marca</p>
                <p className="text-xs text-neutral-400 mt-1">Encendida: la app y el QR ofrecen elegir entre Delivery y Take Away (según qué esté disponible). Apagada: todo sigue exactamente como hasta ahora. Los links y QR actuales funcionan siempre.</p>
              </div>
              <span className={`flex-shrink-0 w-11 h-6 rounded-full transition-colors relative ${config.entrada_unificada ? 'bg-neutral-800' : 'bg-neutral-200'}`}>
                <span className={`absolute top-0.5 w-5 h-5 bg-white rounded-full shadow transition-all ${config.entrada_unificada ? 'left-[22px]' : 'left-0.5'}`} />
              </span>
            </button>
            <div className="p-3 bg-neutral-50 rounded-xl border border-neutral-100">
              <p className="text-sm font-semibold text-neutral-700">Numeración de pedidos</p>
              <p className="text-xs text-neutral-400 mt-1">Numeración correlativa por empresa. El número nunca se reinicia.</p>
            </div>
          </div>
        </ConeCard>

        <ConeCard title="App instalable (PWA)">
          <div className="space-y-2.5">
            <div className="space-y-1">
              <Label>Nombre de la app</Label>
              <Input value={config.pwa_nombre ?? ''} onChange={e => tocar({ pwa_nombre: e.target.value })}
                placeholder="Cecchetto Delivery" />
              <p className="text-xs text-neutral-400">Nombre que aparece al instalar la app en el celular. Vacío = nombre de la empresa.</p>
            </div>
            <div className="space-y-1">
              <Label>Ícono de la app</Label>
              <p className="text-xs text-neutral-400 mb-2">PNG cuadrado, mínimo 192×192px, ideal 512×512.</p>
              {config.pwa_icono_url ? (
                <div className="flex items-center gap-3">
                  <img src={config.pwa_icono_url} alt="Ícono PWA" className="w-16 h-16 rounded-xl object-cover border border-neutral-200" />
                  <ConeButton variant="outline" onClick={() => tocar({ pwa_icono_url: null })} icon={<X className="h-4 w-4" />}>Quitar</ConeButton>
                </div>
              ) : (
                <label className="flex items-center gap-2 px-4 py-2.5 border border-neutral-200 rounded-xl cursor-pointer hover:bg-neutral-50 transition-colors w-fit">
                  <Upload className="h-4 w-4 text-neutral-400" />
                  <span className="text-sm text-neutral-600">Subir ícono</span>
                  <input type="file" accept="image/png,image/jpeg" className="hidden" onChange={async e => {
                    const file = e.target.files?.[0]
                    if (!file || !ctx) return
                    const supabase = createClient()
                    const path = `pwa-icons/${ctx.empresaId}.png`
                    await supabase.storage.from('logos').upload(path, file, { upsert: true })
                    const { data } = supabase.storage.from('logos').getPublicUrl(path)
                    tocar({ pwa_icono_url: data.publicUrl + '?v=' + Date.now() })
                  }} />
                </label>
              )}
            </div>
          </div>
        </ConeCard>

        <ConeCard title="Personalización">
          <div className="space-y-2.5">
            <div className="space-y-1">
              <Label>Mensaje de bienvenida (Kiosk)</Label>
              <Input value={config.texto_bienvenida} onChange={e => tocar({ texto_bienvenida: e.target.value })} placeholder="¡Bienvenido!" />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-1">
                <Label>Color primario</Label>
                <div className="flex gap-2 items-center">
                  <input type="color" value={config.primary_color} onChange={e => tocar({ primary_color: e.target.value })} className="w-10 h-10 rounded-lg cursor-pointer border border-neutral-200" />
                  <Input value={config.primary_color} onChange={e => tocar({ primary_color: e.target.value })} className="font-mono text-sm" maxLength={7} />
                </div>
              </div>
              <div className="space-y-1">
                <Label>Color secundario</Label>
                <div className="flex gap-2 items-center">
                  <input type="color" value={config.secondary_color} onChange={e => tocar({ secondary_color: e.target.value })} className="w-10 h-10 rounded-lg cursor-pointer border border-neutral-200" />
                  <Input value={config.secondary_color} onChange={e => tocar({ secondary_color: e.target.value })} className="font-mono text-sm" maxLength={7} />
                </div>
              </div>
            </div>
          </div>
        </ConeCard>

        <ConeCard title="Logo">
          <div className="space-y-3">
            {config.logo_url ? (
              <div className="relative h-28 rounded-xl overflow-hidden border border-neutral-200 bg-neutral-50 group">
                <Image src={config.logo_url} alt="Logo" fill className="object-contain p-3" />
                <button onClick={() => tocar({ logo_url: null })}
                  className="absolute top-2 right-2 w-7 h-7 bg-red-500 text-white rounded-full flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity shadow-md">
                  <X className="h-4 w-4" />
                </button>
              </div>
            ) : (
              <button onClick={() => logoRef.current?.click()} disabled={uploadingLogo}
                className="w-full h-28 rounded-xl border-2 border-dashed border-neutral-200 bg-neutral-50 hover:bg-neutral-100 hover:border-neutral-300 transition-colors flex flex-col items-center justify-center gap-2 text-neutral-400 disabled:opacity-50">
                {uploadingLogo ? <Loader2 className="h-6 w-6 animate-spin" /> : <Upload className="h-5 w-5" />}
                <span className="text-sm font-medium">{uploadingLogo ? 'Subiendo...' : 'Subir logo'}</span>
                <span className="text-xs text-neutral-300">PNG, SVG recomendado</span>
              </button>
            )}
            <input ref={logoRef} type="file" accept="image/*" className="hidden"
              onChange={e => { const f = e.target.files?.[0]; if (f) handleLogoUpload(f); e.target.value = '' }} />
            <p className="text-xs text-neutral-400">El logo aparece en el kiosk, display y login</p>
          </div>
        </ConeCard>

        <ConeCard title="Vista previa">
          <div className="rounded-xl overflow-hidden border border-neutral-100">
            <div className="p-5 text-white flex items-center gap-3" style={{ backgroundColor: config.primary_color }}>
              {config.logo_url && <Image src={config.logo_url} alt="Logo" width={48} height={48} className="object-contain bg-white rounded-lg p-1" />}
              <div>
                <p className="font-bold text-lg">{config.texto_bienvenida || '¡Bienvenido!'}</p>
                <p className="text-white/60 text-sm">Color primario</p>
              </div>
            </div>
            <div className="p-4" style={{ backgroundColor: config.secondary_color }}>
              <p className="font-semibold text-sm" style={{ color: config.primary_color }}>Color secundario</p>
            </div>
          </div>
        </ConeCard>

      </div>

    </div>
  )
}
