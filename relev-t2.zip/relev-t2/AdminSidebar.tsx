'use client'

import Link from 'next/link'
import { usePathname, useRouter } from 'next/navigation'
import { useState, useEffect } from 'react'
import { createClient } from '@/lib/supabase/client'
import { LayoutDashboard, BookOpen, Store, Users, BarChart3, Settings, LogOut, Truck, Lock, X, Cherry, Gift, FileText, TrendingUp, CreditCard, Clock } from 'lucide-react'

interface Props { usuarioNombre: string; empresaNombre: string; slug: string; modulos: Record<string, boolean>; logoUrl?: string | null }

export default function AdminSidebar({ usuarioNombre, empresaNombre, slug, modulos, logoUrl }: Props) {
  // Contacto comercial de los candados: partner de la empresa o QP por defecto
  const [soporte, setSoporte] = useState<{ nombre: string; wa: string }>({ nombre: 'QP C&IA', wa: '542302456497' })
  useEffect(() => {
    const supabase = createClient()
    supabase.from('empresas').select('id, empresa_config(soporte_nombre, soporte_whatsapp)').eq('slug', slug).single()
      .then(({ data }) => {
        const cfg = Array.isArray(data?.empresa_config) ? data?.empresa_config[0] : data?.empresa_config
        if (cfg?.soporte_whatsapp) setSoporte({ nombre: cfg.soporte_nombre ?? 'tu proveedor', wa: String(cfg.soporte_whatsapp).replace(/\D/g, '') })
      })
  }, [slug])
  const pathname = usePathname()
  const router = useRouter()
  const [modalDelivery, setModalDelivery] = useState(false)
  const [modalBeneficios, setModalBeneficios] = useState(false)
  const [modalFacturacion, setModalFacturacion] = useState(false)

  // MAPA ADMIN v2 (orden JC 22/09): Dashboard → Config. del negocio (+Sucursales
  // hasta su mudanza) → Config. de productos → Cobros → Informes → al fondo lo
  // administrativo. seccion = caption gris sobre el grupo.
  const NAV = [
    { href: `/${slug}/admin`, label: 'Dashboard', icon: LayoutDashboard, exact: true },
    { href: `/${slug}/admin/servicios`, label: 'Config. del negocio', icon: Clock },
    { href: `/${slug}/admin/catalogo`, label: 'Catálogo', icon: BookOpen, seccion: 'Config. de productos' },
    { href: `/${slug}/admin/accesorios`, label: 'Accesorios', icon: Cherry },
    ...(modulos.beneficios === true ? [{ href: `/${slug}/admin/beneficios`, label: 'Beneficios', icon: Gift }] : []),
    { href: `/${slug}/admin/cuentas`, label: 'Cobros', icon: CreditCard, seccion: 'Administración' },
    ...(modulos.facturacion === true ? [{ href: `/${slug}/admin/facturas`, label: 'Facturas', icon: FileText }] : []),
    { href: `/${slug}/admin/ventas`, label: 'Ventas', icon: BarChart3, seccion: 'Informes' },
    { href: `/${slug}/admin/trafico`, label: 'Tráfico', icon: TrendingUp },
    { href: `/${slug}/admin/config`, label: 'Configuración', icon: Settings, seccion: 'Empresa' },
  ]

  const deliveryActivo = modulos.delivery === true

  async function handleLogout() {
    const supabase = createClient()
    await supabase.auth.signOut()
    localStorage.removeItem('coneos-auth')
    router.replace(`/${slug}/login`)
  }

  return (
    <>
      <aside className="w-56 bg-white border-r border-neutral-100 flex flex-col min-h-screen shadow-sm">
        <div className="px-5 py-5 border-b border-neutral-100">
          <div className="flex items-center gap-2.5 mb-0.5">
            {logoUrl ? (
              <img src={logoUrl} alt={empresaNombre}
                className="w-7 h-7 rounded-lg object-cover bg-white border border-neutral-100 flex-shrink-0" />
            ) : (
              <img src="/icon.png" alt="ConeOS"
                className="w-7 h-7 rounded-lg object-cover flex-shrink-0" />
            )}
            <span className="font-black text-neutral-800 truncate">{empresaNombre || 'ConeOS'}</span>
          </div>
          <p className="text-xs text-neutral-400 ml-9 truncate">ConeOS</p>
        </div>

        <nav className="flex-1 px-3 py-4 space-y-0.5">
          {NAV.map(item => {
            const cap = (item as { seccion?: string }).seccion
            const active = item.exact ? pathname === item.href : pathname.startsWith(item.href)
            return (
              <div key={item.href}>
                {cap && <p className="px-3 pt-4 pb-1 text-[10px] font-bold uppercase tracking-widest text-neutral-300">{cap}</p>}
              <Link href={item.href}
                className={`flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-semibold transition-all ${active ? 'bg-neutral-800 text-white' : 'text-neutral-400 hover:text-neutral-700 hover:bg-neutral-50'}`}>
                <item.icon className="h-4 w-4 flex-shrink-0" />
                {item.label}
              </Link>
              </div>
            )
          })}

          {/* Módulo Delivery — bloqueado si no está activo */}
          {!deliveryActivo && (
            <button onClick={() => setModalDelivery(true)}
              className="w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-semibold text-neutral-300 hover:bg-neutral-50 transition-all">
              <Truck className="h-4 w-4 flex-shrink-0" />
              Delivery
              <Lock className="h-3 w-3 ml-auto" />
            </button>
          )}

          {/* Módulo Facturación — bloqueado si no está contratado */}
          {modulos.facturacion !== true && (
            <button onClick={() => setModalFacturacion(true)}
              className="w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-semibold text-neutral-300 hover:bg-neutral-50 transition-all">
              <FileText className="h-4 w-4 flex-shrink-0" />
              Facturación
              <Lock className="h-3 w-3 ml-auto" />
            </button>
          )}

          {/* CASA: el candado de Mesas se mudó a la fila 🪑 de Config. del negocio */}

          {/* Módulo Beneficios — bloqueado si no está contratado */}
          {modulos.beneficios !== true && (
            <button onClick={() => setModalBeneficios(true)}
              className="w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-semibold text-neutral-300 hover:bg-neutral-50 transition-all">
              <Gift className="h-4 w-4 flex-shrink-0" />
              Beneficios
              <Lock className="h-3 w-3 ml-auto" />
            </button>
          )}
        </nav>

        <div className="px-4 py-4 border-t border-neutral-100">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-neutral-800 flex items-center justify-center text-white text-xs font-bold">
              {usuarioNombre?.[0]?.toUpperCase() ?? 'A'}
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-semibold text-neutral-700 truncate">{usuarioNombre}</p>
              <p className="text-xs text-neutral-400">Admin</p>
            </div>
            <button onClick={handleLogout} className="p-1.5 text-neutral-300 hover:text-neutral-600 hover:bg-neutral-100 rounded-lg transition-colors" title="Cerrar sesión">
              <LogOut className="h-4 w-4" />
            </button>
          </div>
        </div>
      </aside>

      {/* Modal facturación bloqueado */}
      {modalFacturacion && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div className="absolute inset-0 bg-black/30 backdrop-blur-sm" onClick={() => setModalFacturacion(false)} />
          <div className="relative bg-white rounded-2xl shadow-xl w-full max-w-sm p-6">
            <button onClick={() => setModalFacturacion(false)} className="absolute top-4 right-4 p-1 text-neutral-400 hover:text-neutral-600">
              <X className="h-5 w-5" />
            </button>
            <div className="w-12 h-12 bg-neutral-100 rounded-2xl flex items-center justify-center mb-4">
              <FileText className="h-6 w-6 text-neutral-400" />
            </div>
            <h3 className="font-black text-neutral-900 text-lg mb-2">Facturación Electrónica</h3>
            <p className="text-neutral-500 text-sm mb-5">Emití Facturas C ante ARCA automáticamente al cobrar, con CAE y QR en el ticket. Incluye listado de comprobantes y notas de crédito. Cumplí con la facturación sin salir del sistema.</p>
            <a href={`https://wa.me/${soporte.wa}?text=${encodeURIComponent(`Hola, quiero activar la Facturación Electrónica en ConeOS`)}`}
              target="_blank" rel="noopener noreferrer"
              className="w-full flex items-center justify-center gap-2 py-3 bg-green-500 hover:bg-green-600 text-white font-bold rounded-xl transition-colors text-sm">
              💬 Contactar a {soporte.nombre}
            </a>
          </div>
        </div>
      )}

      {/* Modal beneficios bloqueado */}
      {modalBeneficios && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div className="absolute inset-0 bg-black/30 backdrop-blur-sm" onClick={() => setModalBeneficios(false)} />
          <div className="relative bg-white rounded-2xl shadow-xl w-full max-w-sm p-6">
            <button onClick={() => setModalBeneficios(false)} className="absolute top-4 right-4 p-1 text-neutral-400 hover:text-neutral-600">
              <X className="h-5 w-5" />
            </button>
            <div className="w-12 h-12 bg-neutral-100 rounded-2xl flex items-center justify-center mb-4">
              <Gift className="h-6 w-6 text-neutral-400" />
            </div>
            <h3 className="font-black text-neutral-900 text-lg mb-2">Programa de Beneficios</h3>
            <p className="text-neutral-500 text-sm mb-5">Fidelizá a tus clientes con puntos por compra canjeables por premios. Sin registro ni contraseñas: solo con el celular. Incluye panel de clientes y canjes configurables.</p>
            <a href={`https://wa.me/${soporte.wa}?text=${encodeURIComponent(`Hola, quiero activar el Programa de Beneficios en ConeOS`)}`}
              target="_blank" rel="noopener noreferrer"
              className="w-full flex items-center justify-center gap-2 py-3 bg-green-500 hover:bg-green-600 text-white font-bold rounded-xl transition-colors text-sm">
              💬 Contactar a {soporte.nombre}
            </a>
          </div>
        </div>
      )}

      {/* Modal delivery bloqueado */}
      {modalDelivery && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div className="absolute inset-0 bg-black/30 backdrop-blur-sm" onClick={() => setModalDelivery(false)} />
          <div className="relative bg-white rounded-2xl shadow-xl w-full max-w-sm p-6">
            <button onClick={() => setModalDelivery(false)} className="absolute top-4 right-4 p-1 text-neutral-400 hover:text-neutral-600">
              <X className="h-5 w-5" />
            </button>
            <div className="w-12 h-12 bg-neutral-100 rounded-2xl flex items-center justify-center mb-4">
              <Truck className="h-6 w-6 text-neutral-400" />
            </div>
            <h3 className="font-black text-neutral-900 text-lg mb-2">Módulo Delivery</h3>
            <p className="text-neutral-500 text-sm mb-5">El módulo de delivery no está incluido en tu plan actual. Incluye gestión de pedidos a domicilio, cadetes, comandas y seguimiento en tiempo real.</p>
            <a href={`https://wa.me/${soporte.wa}?text=${encodeURIComponent(`Hola, quiero activar el módulo de Delivery en ConeOS`)}`}
              target="_blank" rel="noopener noreferrer"
              className="w-full flex items-center justify-center gap-2 py-3 bg-green-500 hover:bg-green-600 text-white font-bold rounded-xl transition-colors text-sm">
              💬 Contactar a {soporte.nombre}
            </a>
          </div>
        </div>
      )}
    </>
  )
}
